package main

import (
	"fmt"
	"os"
	"time"
)

func main() {
	// Initializes a slice to hold command line arguments
	// https://gobyexample.com/command-line-arguments
	argsCommand := os.Args
	argsCommand = os.Args[1:]

	// retrieving command line
	len := argsCommand[0]

	// timing initialized
	start := time.Now()

	// A slice stores to an array; I am storing in both a slice and an array here
	var dynamStore = make([]int, len+1)
	fmt.Printf("\nSlice, Arr took %s", time.Since(start))
	start = time.Now()

	valueStore := make(map[int]int)
	fmt.Printf("\nMap took %s", time.Since(start))
	start = time.Now()

	for i := 0; i <= len; i++ {
		dynamStore[i] = i
		valueStore[i] = i
	}
	fmt.Printf("\nIncrementing took %s", time.Since(start))
	start = time.Now()

}
