package main

import (
	"fmt"
	"math/rand"
	"os"
	"sort"
	"time"
)

func main() {
	// Initializes a slice to hold command line arguments
	// https://gobyexample.com/command-line-arguments
	argsCommand := os.Args
	argsCommand = os.Args[1:]

	// retrieving command line
	length := argsCommand[1]

	// timing initialized
	start := time.Now()

	var (
		//initialize arr and slice
		staticStore  [length]int
		dynamicStore = make([]int, length) //generate rand numbers
	)
	for i, _ := range staticStore {
		staticStore[i] = rand.Int()
		dynamicStore[i] = rand.Int()
	}

	//Stable and Sort from https://pkg.go.dev/sort#Sort

	sort.Stable(staticStore)
	fmt.Printf("\nStable Arr took %s", time.Since(start))
	start = time.Now()

	sort.Sort(staticStore)
	fmt.Printf("\nSort Arr took %s", time.Since(start))
	start = time.Now()

	sort.Stable(dynamicStore)
	fmt.Printf("\nStable Slice took %s", time.Since(start))
	start = time.Now()

	sort.Sort(dynamicStore)
	fmt.Printf("\nSort Slice took %s", time.Since(start))
	start = time.Now()

	// This follows big O for Stable. But Sort is sorting an already sorted array, so it either follows big O as
	// specified, or more likely, it is O(n) at maximum for the calls depending on the algorithm.

}
